// Navbar scroll effect
window.addEventListener('scroll', () => {
  const nav = document.getElementById('mainNav');
  if (!nav) return;
  if (window.scrollY > 50) nav.classList.add('scrolled');
  else if (!nav.dataset.alwaysScrolled) nav.classList.remove('scrolled');
});

// Keep inner pages navbar solid always
document.addEventListener('DOMContentLoaded', () => {
  const nav = document.getElementById('mainNav');
  if (nav && nav.classList.contains('scrolled')) nav.dataset.alwaysScrolled = 'true';

  // Scroll reveal
  const reveals = document.querySelectorAll('.feature-box, .course-card, .faculty-card, .gallery-item');
  reveals.forEach(el => el.classList.add('reveal'));

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add('active');
    });
  }, { threshold: 0.15 });
  reveals.forEach(el => observer.observe(el));

  // Contact form
  const form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = document.getElementById('formMsg');
      msg.classList.remove('d-none');
      form.reset();
      setTimeout(() => msg.classList.add('d-none'), 4000);
    });
  }
});
